/**
  2    * Universidad de La Laguna
  3    * Escuela Superior de Ingeniería y Tecnología
  4    * Grado en Ingeniería Informática
  5    * Informática Básica 2023-2024
  6    *
  7    * @file addone.cc
  8    * @author David Damian alu01674179@ull.edu.es
  9    * @date Oct 22 2023
 10   * @brief The program outputs the digital clock value inputed by the user plus one second
 11    * @bug There are no known bugs
 12    */


#include <iostream>
#include <iomanip>

int main() {

	int a, b, c;
	std::cin >> a >> b >> c;

	c += 1;

	

	if (c==60) {
	b += 1;
	c = 0;
		if (b==60) {
        	a += 1;
        	b = 0;
	
			if (a==24) {
				a = 0;

		}
	}
}	
        std::cout <<  std::setfill('0') << std::setw(2) << a << ":" << std::setfill('0') << std::setw(2) << b << ":" << std::setfill('0') << std::setw(2) << c << std::endl;

}
