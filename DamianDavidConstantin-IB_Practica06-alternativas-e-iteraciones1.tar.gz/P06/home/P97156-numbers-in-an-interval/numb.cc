/**
  2   * Universidad de La Laguna
  3   * Escuela Superior de Ingeniería y Tecnología
  4   * Grado en Ingeniería Informática
  5   * Informática Básica 2023-2024
  6   *
  7   * @file numb.cc
  8   * @author David Damian alu01674179@ull.edu.es
  9   * @date Oct 22 2023
 10   * @brief The program prints the numbers between a and b (which are inputted by the user)
 11   * @bug There are no known bugs
 12   */

#include <iostream>

int main() {
    int a, b;
    std::cin >> a >> b;

    if (a < b) {
        for (int i = a; i <= b; i++) {
            std::cout << i;
            if (i < b) {
                std::cout << ",";
            }
        }
        std::cout << std::endl;
    } else if (a > b) {
        std::cout << std::endl;
    } else if (a == b) {
        std::cout << a << std::endl;
    }

    return 0;
}

