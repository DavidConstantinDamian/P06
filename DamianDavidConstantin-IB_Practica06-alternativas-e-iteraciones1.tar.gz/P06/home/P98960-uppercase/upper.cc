/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file upper.cc
  * @author David Damian alu01674179@ull.edu.es
  * @date Oct 22 2023
  * @brief The program reads a letter and prints the uppercase version (if lowercase) or viceversa
  * @bug There are no known bugs
  */

#include <iostream>
#include <cctype>
#include <limits>

int main() {

	char c;
	std::cin >> c;
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	
	if (islower(c)) {
	std::cout << static_cast<char>(toupper(c)) << std::endl;
}	
	else if (isupper(c)) {
	std::cout << static_cast<char>(tolower(c)) << std::endl;
}
} 	

