/**
  2    * Universidad de La Laguna
  3    * Escuela Superior de Ingeniería y Tecnología
  4    * Grado en Ingeniería Informática
  5    * Informática Básica 2023-2024
  6    *
  7    * @file max.cc
  8    * @author David Damian alu01674179@ull.edu.es
  9    * @date Oct 22 2023
 10   * @brief Program reads three numbers and prints the biggest one
 11    * @bug There are no known bugs
 12    */

#include <iostream>
using namespace std;

int main() {
	
	int a, b, c;
	cin >> a;
	cin >> b;
	cin >> c;

	if (a>=b && a>=c) {
	cout << a << endl;
}

	else if (c>=a && c>=b) {
	cout << c << endl;
}

	else { 
	cout << b << endl;
}
}

