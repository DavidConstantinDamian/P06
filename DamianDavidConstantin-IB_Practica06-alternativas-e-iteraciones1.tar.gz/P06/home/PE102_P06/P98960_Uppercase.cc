#include <iostream>
#include <cctype>
#include <limits>

int main() {

	char c;
	std::cin >> c;
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	
	if (islower(c)) {
	std::cout << static_cast<char>(toupper(c)) << std::endl;
}	
	else if (isupper(c)) {
	std::cout << static_cast<char>(tolower(c)) << std::endl;
}
} 	

