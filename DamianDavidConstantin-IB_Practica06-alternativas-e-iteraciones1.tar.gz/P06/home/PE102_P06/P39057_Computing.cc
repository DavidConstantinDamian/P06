#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>

using namespace std;

int main() {
    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        string shape;
        cin >> shape;

        if (shape == "rectangle") {
            double length, width;
            cin >> length >> width;
            double area = length * width;
            cout << fixed << setprecision(6) << area << endl;
        } else if (shape == "circle") {
            double radius;
            cin >> radius;
            double area = M_PI * radius * radius;
            cout << fixed << setprecision(6) << area << endl;
        }
    }

    return 0;
}

