/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file harm.cc
  * @author David Damian alu01674179@ull.edu.es
  * @date Oct 22 2023
  * @brief The program prints the harmonic number of the value inputted by the user
  * @bug There are no known bugs
  */

#include <iostream>
#include <iomanip>

	int main() {
	int a;
	std::cin >> a;
	double arm= 0.0;
	

	
	for(int i=1; i<=a;i++) {
		

	arm += 1.0/i;  
	 
}
	std::cout << std::fixed << std::setprecision(4) << arm << std::endl;	
}


